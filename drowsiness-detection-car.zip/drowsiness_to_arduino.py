# drowsiness_to_arduino.py
# Requirements: opencv-python, mediapipe, pyserial
import cv2
import mediapipe as mp
import time
import serial
import serial.tools.list_ports
import math

# ---------- USER CONFIG ----------
SERIAL_PORT = 'COM3'      # change to your Arduino serial port (Windows) or '/dev/ttyUSB0' on Linux
BAUDRATE = 115200
EYE_CLOSED_SECONDS_THRESHOLD = 3.0
SEND_COMMAND_INTERVAL = 1.0  # seconds, frequency to re-send command
CAM_INDEX = 0              # webcam index (0,1...) or use video URL if your phone provides it
# ---------------------------------

def find_arduino_port():
    ports = list(serial.tools.list_ports.comports())
    for p in ports:
        if 'Arduino' in p.description or 'USB Serial' in p.description or 'ttyACM' in p.device:
            return p.device
    return None

if SERIAL_PORT in (None, '', 'AUTO'):
    detected = find_arduino_port()
    if detected:
        SERIAL_PORT = detected
        print(f"Auto-detected Arduino at {SERIAL_PORT}")
    else:
        print("No Arduino auto-detected; make sure SERIAL_PORT is set correctly.")

ser = None
try:
    ser = serial.Serial(SERIAL_PORT, BAUDRATE, timeout=1)
    time.sleep(2)
    print(f"Connected to Arduino on {SERIAL_PORT}")
except Exception as e:
    print(f"Warning: cannot open serial {SERIAL_PORT}: {e}")
    ser = None

mp_face = mp.solutions.face_mesh
face_mesh = mp_face.FaceMesh(max_num_faces=1,
                            refine_landmarks=True,
                            min_detection_confidence=0.5,
                            min_tracking_confidence=0.5)

LEFT_EYE_IDX = [33, 160, 158, 133, 153, 144]
RIGHT_EYE_IDX = [362, 385, 387, 263, 373, 380]

def eye_aspect_ratio(landmarks, eye_idx, img_w, img_h):
    pts = []
    for idx in eye_idx:
        lm = landmarks[idx]
        x = int(lm.x * img_w)
        y = int(lm.y * img_h)
        pts.append((x, y))
    def dist(a, b): return math.hypot(a[0]-b[0], a[1]-b[1])
    p1, p2, p3, p4, p5, p6 = pts
    ear = (dist(p2, p6) + dist(p3, p5)) / (2.0 * (dist(p1, p4) + 1e-6))
    return ear, pts

EAR_CLOSED_THRESHOLD = 0.18

cap = cv2.VideoCapture(CAM_INDEX)
if not cap.isOpened():
    print("Cannot open camera.")
    exit(1)

closed_start_time = None
last_command_time = 0
current_state = 'NORMAL'

while True:
    ret, frame = cap.read()
    if not ret:
        break
    img_h, img_w = frame.shape[:2]
    rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    results = face_mesh.process(rgb)

    both_eyes_closed = False
    if results.multi_face_landmarks:
        lm = results.multi_face_landmarks[0].landmark
        ear_left, pts_left = eye_aspect_ratio(lm, LEFT_EYE_IDX, img_w, img_h)
        ear_right, pts_right = eye_aspect_ratio(lm, RIGHT_EYE_IDX, img_w, img_h)
        ear = (ear_left + ear_right) / 2.0

        for p in pts_left + pts_right:
            cv2.circle(frame, p, 2, (0,255,0), -1)

        if ear < EAR_CLOSED_THRESHOLD:
            if closed_start_time is None:
                closed_start_time = time.time()
            elapsed = time.time() - closed_start_time
            cv2.putText(frame, f"CLOSED {elapsed:.2f}s", (30, 60), cv2.FONT_HERSHEY_SIMPLEX, 0.9, (0,0,255), 2)
            if elapsed >= EYE_CLOSED_SECONDS_THRESHOLD:
                both_eyes_closed = True
                for p in pts_left + pts_right:
                    cv2.circle(frame, p, 4, (0,0,255), -1)
        else:
            closed_start_time = None
            cv2.putText(frame, f"EAR {ear:.3f}", (30,60), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0,255,0), 2)
    else:
        closed_start_time = None
        cv2.putText(frame, "No face detected", (30,60), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0,255,255), 2)

    now = time.time()
    if both_eyes_closed:
        if current_state != 'SLOW_LEFT' or (now - last_command_time) > SEND_COMMAND_INTERVAL:
            cmd = 'SLOW_LEFT\n'
            if ser:
                try:
                    ser.write(cmd.encode())
                except Exception as e:
                    print("Serial write failed:", e)
                    ser = None
            current_state = 'SLOW_LEFT'
            last_command_time = now
        cv2.putText(frame, "ALERT: Driver drowsy!", (30,100), cv2.FONT_HERSHEY_DUPLEX, 1.0, (0,0,255), 2)
    else:
        if current_state != 'NORMAL' and (now - last_command_time) > SEND_COMMAND_INTERVAL:
            cmd = 'NORMAL\n'
            if ser:
                try:
                    ser.write(cmd.encode())
                except Exception as e:
                    print("Serial write failed:", e)
                    ser = None
            current_state = 'NORMAL'
            last_command_time = now

    cv2.imshow('Drowsiness Detection', frame)
    key = cv2.waitKey(1) & 0xFF
    if key == 27 or key == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()
if ser:
    ser.close()
