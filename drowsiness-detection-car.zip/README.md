# 🚗 Drowsiness Detection System with Arduino Controlled Car

This project detects driver drowsiness using a camera and controls a toy car for safety.

- Eye tracking with Python (OpenCV + MediaPipe).
- Sends command to Arduino via Serial when drowsiness detected.
- Arduino reduces speed, blinks left indicator, and avoids obstacles.

## Usage
1. Connect phone camera as webcam (DroidCam).
2. Run Python script:
   ```bash
   python drowsiness_to_arduino.py
   ```
3. Upload Arduino sketch to board.
